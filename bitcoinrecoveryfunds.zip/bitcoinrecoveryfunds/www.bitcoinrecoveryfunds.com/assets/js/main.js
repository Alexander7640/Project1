!(function($) {
  "use strict";

  // Smooth scroll for the navigation menu and links with .scrollto classes
  var scrolltoOffset = $('#header').outerHeight() - 2;
  $(document).on('click', '.nav-menu a, .mobile-nav a, .scrollto', function(e) {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var target = $(this.hash);
      if (target.length) {
        e.preventDefault();

        var scrollto = target.offset().top - scrolltoOffset;

        if ($(this).attr("href") == '#header') {
          scrollto = 0;
        }

        $('html, body').animate({
          scrollTop: scrollto
        }, 1500, 'easeInOutExpo');

        if ($(this).parents('.nav-menu, .mobile-nav').length) {
          $('.nav-menu .active, .mobile-nav .active').removeClass('active');
          $(this).closest('li').addClass('active');
        }

        if ($('body').hasClass('mobile-nav-active')) {
          $('body').removeClass('mobile-nav-active');
          $('.mobile-nav-toggle i').toggleClass('icofont-navigation-menu icofont-close');
          $('.mobile-nav-overly').fadeOut();
        }
        return false;
      }
    }
  });

  // Activate smooth scroll on page load with hash links in the url
  $(document).ready(function() {
    if (window.location.hash) {
      var initial_nav = window.location.hash;
      if ($(initial_nav).length) {
        var scrollto = $(initial_nav).offset().top - scrolltoOffset;
        $('html, body').animate({
          scrollTop: scrollto
        }, 1500, 'easeInOutExpo');
      }
    }
  });

  // Mobile Navigation
  if ($('.nav-menu').length) {
    var $mobile_nav = $('.nav-menu').clone().prop({
      class: 'mobile-nav d-lg-none'
    });
    $('body').append($mobile_nav);
    $('body').append('<div class="mobile-nav-overly"></div>');
    $('body').prepend('<button type="button" class="mobile-nav-toggle d-lg-none"><i class="icofont-navigation-menu"></i></button>');


    $(document).on('click', '.mobile-nav-toggle', function(e) {
      $('body').toggleClass('mobile-nav-active');
      $('.mobile-nav-toggle i').toggleClass('icofont-navigation-menu icofont-close');
      $('.mobile-nav-overly').toggle();
    });

    $(document).on('click', '.mobile-nav .drop-down > a', function(e) {
      e.preventDefault();
      $(this).next().slideToggle(300);
      $(this).parent().toggleClass('active');
    });

    $(document).click(function(e) {
      var container = $(".mobile-nav, .mobile-nav-toggle");
      if (!container.is(e.target) && container.has(e.target).length === 0) {
        if ($('body').hasClass('mobile-nav-active')) {
          $('body').removeClass('mobile-nav-active');
          $('.mobile-nav-toggle i').toggleClass('icofont-navigation-menu icofont-close');
          $('.mobile-nav-overly').fadeOut();
        }
      }
    });
  } else if ($(".mobile-nav, .mobile-nav-toggle").length) {
    $(".mobile-nav, .mobile-nav-toggle").hide();
  }

  // Intro carousel
  var heroCarousel = $("#heroCarousel");
  var heroCarouselIndicators = $("#hero-carousel-indicators");
  heroCarousel.find(".carousel-inner").children(".carousel-item").each(function(index) {
    (index === 0) ?
    heroCarouselIndicators.append("<li data-target='#heroCarousel' data-slide-to='" + index + "' class='active'></li>"):
      heroCarouselIndicators.append("<li data-target='#heroCarousel' data-slide-to='" + index + "'></li>");
  });

  heroCarousel.on('slid.bs.carousel', function(e) {
    $(this).find('.carousel-content ').addClass('animate__animated animate__fadeInDown');
  });

  // Back to top button
  $(window).scroll(function() {
    if ($(this).scrollTop() > 100) {
      $('.back-to-top').fadeIn('slow');
    } else {
      $('.back-to-top').fadeOut('slow');
    }
  });

  $('.back-to-top').click(function() {
    $('html, body').animate({
      scrollTop: 0
    }, 1500, 'easeInOutExpo');
    return false;
  });

  // Porfolio isotope and filter
  $(window).on('load', function() {
    var portfolioIsotope = $('.portfolio-container').isotope({
      itemSelector: '.portfolio-item'
    });

    $('#portfolio-flters li').on('click', function() {
      $("#portfolio-flters li").removeClass('filter-active');
      $(this).addClass('filter-active');

      portfolioIsotope.isotope({
        filter: $(this).data('filter')
      });
      aos_init();
    });

  });

  // Skills section
  $('.skills-content').waypoint(function() {
    $('.progress .progress-bar').each(function() {
      $(this).css("width", $(this).attr("aria-valuenow") + '%');
    });
  }, {
    offset: '80%'
  });

  // Portfolio details carousel
  $(".portfolio-details-carousel").owlCarousel({
    autoplay: true,
    dots: true,
    loop: true,
    items: 1
  });

  // Init AOS
  function aos_init() {
    AOS.init({
      duration: 1000,
      once: true
    });
  }
  $(window).on('load', function() {
    aos_init();
  });

})(jQuery);

function onMouseOut(event) {
  // If the mouse is near the top of the window, show the popup
  if (event.clientY < 50) {
    // Remove this event listener
    document.removeEventListener("mouseout", onMouseOut);

    // Show the popup
    document.getElementById("popup").style.display = "block";
  }
}

if ($(window).width() > 768) {
  document.addEventListener("mouseout", onMouseOut);
}

// Close popup button
function closePop() {
  document.getElementById("popup").style.display = "none";
}


// Show company
const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const company = urlParams.get('company');
if (company) {
  document.getElementById("broker_pdr").innerHTML = company;
  document.getElementById("company").value = company;
  document.getElementById("company_pop").value = company;
}


// Change Country
$.getJSON('https://ipapi.co/json/', function(data) {
  let country = data.country_name;
  if (country) {
    document.getElementById('country').value=country;
    document.getElementById('country_pop').value=country;
  }
});


// reCAPTCHA v3
function onSubmitTop(token) {

  let form, recaptchaResponse, text, errorTag;

  form = document.getElementById("top_form");

  errorTag = "errorTextTop";

  // Name check
  if (form["name"].value == "") {
    text = "Please provide your name";
    form["name"].focus();
  } else if (form["phone"].value == "" || form["phone"].value.length < 3) { // Phone check
    text = "Please provide a valid phone number";
    form["phone"].focus();
  } else if (form["email"].value == "" || form["email"].value.length < 5 || form["email"].value.search("@") == -1) {
    // Email Check
    text = "Please provide a valid email";
    form["email"].focus();
  } else if (form["amount"].value == "") { // Amount check
    text = "Please provide a valid amount of investments";
    form["amount"].focus();
  } else if (form["country"].value == "") { // Country check
    text = "Please select your country";
    form["country"].focus();
  }

  // Checking if everything was okay
  if (!text) {
    document.getElementById(errorTag).style.display = "block";
    document.getElementById(errorTag).style.color = "green";
    document.getElementById(errorTag).innerText = "Processing...";

    recaptchaResponse = document.createElement('input');
    recaptchaResponse.type = 'hidden';
    recaptchaResponse.name = 'recaptcha_response';
    recaptchaResponse.id = "recaptchaResponse";
    recaptchaResponse.value = token;

    form.appendChild(recaptchaResponse);

    form.submit();
  } else {
    document.getElementById(errorTag).style.display = "block";
    document.getElementById(errorTag).innerText = text;
  }
}

function onSubmitMobile(token) {

  let form, recaptchaResponse, text, errorTag;

  form = document.getElementById("mobile_form");

  errorTag = "errorTextMobile";

  // Name check
  if (form["name"].value == "") {
    text = "Please provide your name";
    form["name"].focus();
  } else if (form["phone"].value == "" || form["phone"].value.length < 3) { // Phone check
    text = "Please provide a valid phone number";
    form["phone"].focus();
  } else if (form["email"].value == "" || form["email"].value.length < 5 || form["email"].value.search("@") == -1) {
    // Email Check
    text = "Please provide a valid email";
    form["email"].focus();
  } else if (form["amount"].value == "") { // Amount check
    text = "Please provide a valid amount of investments";
    form["amount"].focus();
  } else if (form["country"].value == "") { // Country check
    text = "Please select your country";
    form["country"].focus();
  }

  // Checking if everything was okay
  if (!text) {
    document.getElementById(errorTag).style.display = "block";
    document.getElementById(errorTag).style.color = "green";
    document.getElementById(errorTag).innerText = "Processing...";

    recaptchaResponse = document.createElement('input');
    recaptchaResponse.type = 'hidden';
    recaptchaResponse.name = 'recaptcha_response';
    recaptchaResponse.id = "recaptchaResponse";
    recaptchaResponse.value = token;

    form.appendChild(recaptchaResponse);

    form.submit();
  } else {
    document.getElementById(errorTag).style.display = "block";
    document.getElementById(errorTag).innerText = text;
  }
}

function onSubmitPopup(token) {

  let form, recaptchaResponse, text, errorTag;

  form = document.getElementById("popup_form");

  errorTag = "errorTextPopup";

  // Name check
  if (form["name"].value == "") {
    text = "Please provide your name";
    form["name"].focus();
  } else if (form["phone"].value == "" || form["phone"].value.length < 3) { // Phone check
    text = "Please provide a valid phone number";
    form["phone"].focus();
  } else if (form["email"].value == "" || form["email"].value.length < 5 || form["email"].value.search("@") == -1) {
    // Email Check
    text = "Please provide a valid email";
    form["email"].focus();
  } else if (form["amount"].value == "") { // Amount check
    text = "Please provide a valid amount of investments";
    form["amount"].focus();
  } else if (form["country"].value == "") { // Country check
    text = "Please select your country";
    form["country"].focus();
  }

  // Checking if everything was okay
  if (!text) {
    document.getElementById(errorTag).style.display = "block";
    document.getElementById(errorTag).style.color = "green";
    document.getElementById(errorTag).innerText = "Processing...";

    recaptchaResponse = document.createElement('input');
    recaptchaResponse.type = 'hidden';
    recaptchaResponse.name = 'recaptcha_response';
    recaptchaResponse.id = "recaptchaResponse";
    recaptchaResponse.value = token;

    form.appendChild(recaptchaResponse);

    form.submit();
  } else {
    document.getElementById(errorTag).style.display = "block";
    document.getElementById(errorTag).innerText = text;
  }
}


// Mozilla support
let isFirefox = typeof InstallTrigger !== 'undefined';
if (isFirefox) {
  let cssId = 'myCss';  // you could encode the css path itself to generate id..
  if (!document.getElementById(cssId))
  {
    let head  = document.getElementsByTagName('head')[0];
    let link  = document.createElement('link');
    link.id   = cssId;
    link.rel  = 'stylesheet';
    link.type = 'text/css';
    link.href = 'assets/tidy.css';
    link.media = 'all';
    head.appendChild(link);
  }
}
